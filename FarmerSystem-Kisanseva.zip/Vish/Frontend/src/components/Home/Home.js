
import Card from "./Card";
import Slider from "./Slider";
import './home.css'
import './card.css'
function Home() {
    const myStyle = {
        backgroundImage:
            "url('https://wallpaperaccess.com/full/4293117.jpg')",
        height: '130vh',
    
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
    };


    return (
        <div className="gradient__bg">



            
            <div style={myStyle}>
              <div className="cardstyle">

                   <Card />
              </div>
               
                        
            </div>

            {/* <Slider /> */}

        </div>



    )
};

export default Home;