
function TermsandCondition()
{
    return(
        <div>
            <span>If Buyer paid successfully to the farmer then Farmer has to deliver product in 15 days or return the payment to the buyer</span>
        </div>
    )
}

export default TermsandCondition;